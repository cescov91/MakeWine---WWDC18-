//: Playground - noun: a place where people can play


// CREDIT flame img <a href="https://www.freepik.com/free-vector/decorative-flame-collection_1085963.htm">Designed by Freepik</a>


import UIKit
import SpriteKit
import PlaygroundSupport



let view = SKView(frame: CGRect(x: 0, y: 0, width: 600.0, height: 700.0))

let game = Menu(size: view.frame.size)

game.scaleMode = .aspectFit



view.presentScene(game)
PlaygroundPage.current.liveView = view



