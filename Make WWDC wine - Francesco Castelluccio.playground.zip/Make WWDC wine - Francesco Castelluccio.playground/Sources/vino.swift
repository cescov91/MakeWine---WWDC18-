import Foundation
import SpriteKit
import UIKit


// The scene of Vine Game
public class Vino: SKScene{
    
    
   //Declare two UISwipeGestureRecognizer that i will use
     let swipeDownRec = UISwipeGestureRecognizer()
     let swipeLeftRec = UISwipeGestureRecognizer()
    
    
    
    //Audio nodes
     let vinoAudio1 = SKAudioNode(fileNamed:"audioVino1.mp3")
     let vinoAudio2 = SKAudioNode(fileNamed:"audioVino2.mp3")
     let vinoAudio3 = SKAudioNode(fileNamed:"audioVino3.mp3")
    

    
    // Image nodes for the Vino Game
    let backgroundVino = SKSpriteNode(texture: SKTexture(imageNamed: "sfondoVino.png"))
    let imgUva = SKSpriteNode(texture: SKTexture(imageNamed: "grappolo.png"))
    let imgMacchina = SKSpriteNode(texture: SKTexture(imageNamed: "macchina.png"))
    let imgMacchinaPiena = SKSpriteNode(texture: SKTexture(imageNamed: "macchinaPiena.png"))
    let imgMacchinaPienaUva = SKSpriteNode(texture: SKTexture(imageNamed: "macchinaPienauva.png"))
    let imgBarile = SKSpriteNode(texture: SKTexture(imageNamed: "bottevuota.png"))
    let imgBarilePieno = SKSpriteNode(texture: SKTexture(imageNamed: "bottepiena.png"))
    let imgGocceVino = SKSpriteNode(texture: SKTexture(imageNamed: "goccia.png"))
    let imgSwitchOff = SKSpriteNode(texture: SKTexture(imageNamed: "off.png"))
    let imgSwitchOn = SKSpriteNode(texture: SKTexture(imageNamed: "on.png"))
    
    
    override public func didMove(to view: SKView) {
        createVinoScene()
    }
    
    
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let touch = touches.first
        let touchLocation = touch!.location(in: self)
        
        if imgSwitchOff.contains(touchLocation){
            turnOnMachine()
        }
    }
    
    
    
    /*------------------------------------------------------------------------------------------*/
    /// This function is called by didView and create the scene
    func createVinoScene(){
        
        //Setting of the nodes
        
        backgroundVino.position = CGPoint(x: 0.0, y: 0.0)
        backgroundVino.setScale(4)
        backgroundVino.name = "backgroundVino"
        
        imgUva.position = CGPoint(x: 300.0, y: 700.0)
        imgUva.setScale(0.5)
        imgUva.name = "imgUva"
        
        imgSwitchOff.position = CGPoint(x: 450.0, y: 250.0)
        imgSwitchOff.setScale(0.05)
        imgSwitchOff.name = "imgSwitchOff"
        
        imgSwitchOn.position = CGPoint(x: 450.0, y: 250.0)
        imgSwitchOn.setScale(0.05)
        imgSwitchOn.name = "imgSwitchOn"
        
        imgMacchina.position = CGPoint(x: 300.0, y: 300.0)
        imgMacchina.setScale(0.5)
        imgMacchina.name = "imgMacchina"
        
        imgMacchinaPiena.position = CGPoint(x: 300.0, y: 300.0)
        imgMacchinaPiena.setScale(0.5)
        imgMacchinaPiena.name = "imgMacchinaPiena"
        
        imgMacchinaPienaUva.position = CGPoint(x: 300.0, y: 300.0)
        imgMacchinaPienaUva.setScale(0.5)
        imgMacchinaPienaUva.name = "imgMacchinaPienaUva"
        
        imgGocceVino.position = CGPoint(x: 300.0, y: 200.0)
        imgGocceVino.setScale(0.3)
        imgGocceVino.name = "imgGocceVino"
        
        imgBarile.position = CGPoint(x: 300.0, y: 80.0)
        imgBarile.setScale(0.5)
        imgBarile.name = "imgBarile"
        
        imgBarilePieno.position = CGPoint(x: 300.0, y: 80.0)
        imgBarilePieno.setScale(0.5)
        imgBarilePieno.name = "imgBarilePieno"
        
        playVino()

    }
    
    
    /*------------------------------------------------------------------------------------------*/
    /// Function to play the game of the Vino
    
    func playVino() {
        //Swipe down to drop the grapes and adding nodes to the scene
        
        swipeDownRec.addTarget(self, action: #selector(Vino.swipedDown) )
        swipeDownRec.direction = .down
        self.view!.addGestureRecognizer(swipeDownRec)
        self.addChild(vinoAudio1)
        
        self.addChild(backgroundVino)
        self.addChild(imgMacchina)
        self.addChild(imgMacchinaPienaUva)
        self.addChild(imgUva)
        //Some nodes are hidden to make a fadeIn/out effect
        imgUva.isHidden = true
        self.addChild(imgBarile)
        self.addChild(imgGocceVino)
        imgGocceVino.isHidden = true
        self.addChild(imgSwitchOff)
        self.addChild(imgMacchinaPiena)
        self.addChild(imgBarilePieno)
        
        //declaration of the fadeout
        let fadeout = SKAction.fadeOut(withDuration: 0)
        imgMacchinaPiena.run(fadeout)
        imgMacchinaPienaUva.run(fadeout)
        imgBarilePieno.run(fadeout)
        
    }
    
    
    // Swipe down
    
    @objc func swipedDown() {
        
        imgUva.isHidden = false
        let moveNodeDown = SKAction.moveBy(x: 0.0, y: -400.0, duration: 2.0)
        let rotation = SKAction.rotate(byAngle: 360, duration: 2)
        let group = SKAction.group([moveNodeDown, rotation])
        imgUva.run(group)
        
        vinoAudio1.run(SKAction.stop())
        self.addChild(vinoAudio2)
        
        let fadeIn = SKAction.fadeIn(withDuration: 2)
        imgMacchinaPienaUva.run(fadeIn)
        
        
    }
    
    
    
    
    
    
    /*_____________________________________________*/
    //This function is the second part of the game. Other nodes are added
    
    func turnOnMachine() {
        
        vinoAudio2.run(SKAction.stop())
        
        self.addChild(vinoAudio3)
        
        imgSwitchOff.removeFromParent()
        self.addChild(imgSwitchOn)
        let moveNodeDown = SKAction.moveBy(x: 0.0, y: -50.0, duration: 1.0)
        
        
        //A copy of an existent node, but with different property
        let copiaGoccia = imgGocceVino.copy() as! SKSpriteNode
        copiaGoccia.position = CGPoint(x: 160.0, y: 200.0)
        copiaGoccia.setScale(0.1)
        self.addChild(copiaGoccia)
        
        let copiaGoccia2 = imgGocceVino.copy() as! SKSpriteNode
        copiaGoccia2.position = CGPoint(x: 230.0, y: 210.0)
        copiaGoccia2.setScale(0.2)
        self.addChild(copiaGoccia2)
        
        let copiaGoccia3 = imgGocceVino.copy() as! SKSpriteNode
        copiaGoccia3.position = CGPoint(x: 330.0, y: 198.0)
        copiaGoccia3.setScale(0.22)
        self.addChild(copiaGoccia3)
        
        let copiaGoccia4 = imgGocceVino.copy() as! SKSpriteNode
        copiaGoccia4.position = CGPoint(x: 405.0, y: 190.0)
        copiaGoccia4.setScale(0.15)
        self.addChild(copiaGoccia4)
        
        imgGocceVino.isHidden = false
        copiaGoccia.isHidden = false
        copiaGoccia2.isHidden = false
        copiaGoccia3.isHidden = false
        copiaGoccia4.isHidden = false
        
        imgGocceVino.run(moveNodeDown)
        copiaGoccia.run(moveNodeDown)
        copiaGoccia2.run(moveNodeDown)
        copiaGoccia3.run(moveNodeDown)
        copiaGoccia4.run(moveNodeDown)
        
        
        
        
        let fadeIn = SKAction.fadeIn(withDuration: 2)
        let fadeoutVeloce = SKAction.fadeOut(withDuration: 2)
        let fadeout = SKAction.fadeOut(withDuration: 4)
        
        imgGocceVino.run(fadeoutVeloce)
        copiaGoccia.run(fadeoutVeloce)
        copiaGoccia2.run(fadeoutVeloce)
        copiaGoccia3.run(fadeoutVeloce)
        copiaGoccia4.run(fadeoutVeloce)
        
        imgMacchinaPienaUva.run(fadeoutVeloce)
        imgMacchinaPiena.run(fadeIn)
        
        imgBarile.run(fadeout)
        imgBarilePieno.run(fadeIn)
        
        
        swipeLeftRec.addTarget(self, action: #selector(Vino.swipedLeft) )
        swipeLeftRec.direction = .left
        self.view!.addGestureRecognizer(swipeLeftRec)
        
    }
    
    
    //Swipe left and scene change
    
    @objc func swipedLeft() {
        
        vinoAudio3.run(SKAction.stop())
        let transition:SKTransition = SKTransition.fade(withDuration: 1)
        let scene:SKScene = VinoFinal(size: self.size)
        scene.scaleMode = .aspectFit
        self.view?.presentScene(scene, transition: transition)
        
    }
}
