import Foundation
import SpriteKit
import UIKit

public class GrappaFinal: SKScene{
    
    let grappaBottone = SKSpriteNode(texture: SKTexture(imageNamed: "bottilgliaGrappaFinale"))
    let background = SKSpriteNode(texture: SKTexture(imageNamed: "sfondoGrappa.png"))
    let audioGrappa3 = SKAudioNode(fileNamed:"audiograppa3.mp3")
    
    override public func didMove(to view: SKView) {
        
        self.addChild(audioGrappa3)
        
        background.position = CGPoint(x: 0.0, y: 0.0)
        background.setScale(4)
        background.name = "background"
        self.addChild(background)
        
        grappaBottone.position = CGPoint(x: 300.0, y: 200.0)
        grappaBottone.setScale(0.4)
        grappaBottone.name = "grappaBottone"
        self.addChild(grappaBottone)
    }
    
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let touch = touches.first
        let touchLocation = touch!.location(in: self)
        
        if grappaBottone.contains(touchLocation){
            print("Torna indietro")
            
            audioGrappa3.run(SKAction.stop())
            let transition:SKTransition = SKTransition.fade(withDuration: 1)
            let scene:SKScene = Menu(size: self.size)
            scene.scaleMode = .aspectFit
            self.view?.presentScene(scene, transition: transition)
        }
        
        
    }
    
}
