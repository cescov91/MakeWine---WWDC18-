import Foundation
import SpriteKit
import UIKit

// The scene of Grappa Game
public class Grappa: SKScene{
    
    
     let swipeLeftRec = UISwipeGestureRecognizer()
    
    
    
    //Audio node
     let audioGrappa1 = SKAudioNode(fileNamed:"audiograppa1.mp3")
     
    
    //UISLider to set the temperature
    let slider = UISlider(frame:CGRect(x: 50, y: 550, width: 100, height: 30))
    
    
    // Grappa nodes
    let backgroundGrappa = SKSpriteNode(texture: SKTexture(imageNamed: "sfondoGrappa.png"))
    let imgAlambicco = SKSpriteNode(texture: SKTexture(imageNamed: "alambicco2.png"))
    let imgFuoco = SKSpriteNode(texture: SKTexture(imageNamed: "fiamma.png"))
    let imgContenitore = SKSpriteNode(texture: SKTexture(imageNamed: "bicchiere.png"))
    let label = SKLabelNode(fontNamed: "Verdana")

    
    
    override public func didMove(to view: SKView) {
        createGrappaScene()
    }
    
    
    
    /*------------------------------------------------------------------------------------------*/
    /// This function is called by didView and create the scene
    func createGrappaScene(){
        
        
        //Setting of the nodes
        
        backgroundGrappa.position = CGPoint(x: 0.0, y: 0.0)
        backgroundGrappa.setScale(4)
        backgroundGrappa.name = "backgroundGrappa"
        
        imgAlambicco.position = CGPoint(x: 300.0, y: 400.0)
        imgAlambicco.setScale(0.5)
        imgAlambicco.name = "imgAlambicco"
        
        imgFuoco.position = CGPoint(x: 180.0, y: 220.0)
        imgFuoco.setScale(0.4)
        imgFuoco.name = "imgFuoco"
        
        imgContenitore.position = CGPoint(x: 550.0, y: 200.0)
        imgContenitore.setScale(0.5)
        imgContenitore.name = "imgContenitore"
        
        
        
        label.fontSize = 21
        label.fontColor = SKColor.black
        label.position = CGPoint(x: 184, y: 128)
        
        playGrappa()
        
    }
    
    

    /*_____________________________________________*/
    // Function to play the game of the Grappa
    
    func playGrappa() {
        
        //Slider setting and adding to the view
        slider.minimumValue = 25
        slider.maximumValue = 80
        slider.isContinuous = true
        slider.addTarget(self, action: #selector(Grappa.sliderValueDidChange(_:)), for: .valueChanged)
        view!.addSubview(slider)
        
        self.addChild(audioGrappa1)
        self.addChild(backgroundGrappa)
        self.addChild(imgAlambicco)
        self.addChild(imgFuoco)
        imgFuoco.isHidden = true
        self.addChild(imgContenitore)
        let fadeout = SKAction.fadeOut(withDuration: 0)
        imgContenitore.run(fadeout)
        self.addChild(label)
        
    }
    
    
    // Slider
   @objc func sliderValueDidChange(_ slider:UISlider!)
    {
       //A label that contain the valure of the slider
        label.text = String(Int(slider.value)) + "°"
        imgFuoco.isHidden = false
        
    
        if slider.value >= 80 {
            
            let fadeIn = SKAction.fadeIn(withDuration: 2)
            imgContenitore.run(fadeIn)
            swipeLeftRec.addTarget(self, action: #selector(Grappa.swipedLeft) )
            swipeLeftRec.direction = .left
            self.view!.addGestureRecognizer(swipeLeftRec)
        }
        
    }
    
    //Swipe left and scene change

    @objc func swipedLeft() {
        
         audioGrappa1.run(SKAction.stop())
        slider.removeFromSuperview()
        let transition:SKTransition = SKTransition.fade(withDuration: 1)
        let scene:SKScene = GrappaFinal(size: self.size)
        scene.scaleMode = .aspectFit
        self.view?.presentScene(scene, transition: transition)
        
    }

}
