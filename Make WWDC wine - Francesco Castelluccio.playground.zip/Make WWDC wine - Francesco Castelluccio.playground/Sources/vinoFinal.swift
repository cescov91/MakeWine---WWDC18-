import Foundation
import SpriteKit
import UIKit

public class VinoFinal: SKScene{

    let vinoBottone = SKSpriteNode(texture: SKTexture(imageNamed: "bottilgliaVinoFinale.png"))
    let background = SKSpriteNode(texture: SKTexture(imageNamed: "sfondoVino.png"))
    let vinoAudio4 = SKAudioNode(fileNamed:"audioVino4.mp3")
    
    override public func didMove(to view: SKView) {
        
        self.addChild(vinoAudio4)
        
        background.position = CGPoint(x: 0.0, y: 0.0)
        
        background.setScale(4)
        background.name = "background"
        self.addChild(background)
        
        vinoBottone.position = CGPoint(x: 300.0, y: 200.0)
        vinoBottone.setScale(0.4)
        vinoBottone.name = "grappaBottone"
        self.addChild(vinoBottone)
    }
    
    //Come back function when the bottle is touched
    
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let touch = touches.first
        let touchLocation = touch!.location(in: self)
        
        if vinoBottone.contains(touchLocation){
            vinoAudio4.run(SKAction.stop())
            let transition:SKTransition = SKTransition.fade(withDuration: 1)
            let scene:SKScene = Menu(size: self.size)
            scene.scaleMode = .aspectFit
            self.view?.presentScene(scene, transition: transition)
        }
        
        
    }

}
