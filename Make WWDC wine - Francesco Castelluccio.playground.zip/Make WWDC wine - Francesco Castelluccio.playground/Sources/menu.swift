import Foundation
import SpriteKit
import UIKit


// The scene of Menu
public class Menu: SKScene{
    
    
    
    
    // Nodes for the menu
    let background = SKSpriteNode(texture: SKTexture(imageNamed: "sfondo.png"))
    let vinoBottone = SKSpriteNode(texture: SKTexture(imageNamed: "bottilgliaVinoIniziale.png"))
    let grappaBottone = SKSpriteNode(texture: SKTexture(imageNamed: "bottilgliaGrappaIniziale.png"))
    
    // AudioNodes for the menu
    let audioMenu = SKAudioNode(fileNamed:"audioMenu.mp3")
    
    
    
    //________________________________________________________________________
    // First view to load
    override public func didMove(to view: SKView) {
        //This is the funtion that create a menu Scene
        createMenuScene()
    }
    
    /*------------------------------------------------------------------------------------------*/
    // In this function i set the nodes
    func createMenuScene(){
        
        //position of the node
        background.position = CGPoint(x: 0.0, y: 0.0)
        //set the scale of the node
        background.setScale(4)
        //Add the node to the scene
        self.addChild(background)
        
        //The same for the other nodes but with different position and scale
        vinoBottone.position = CGPoint(x: 200.0, y: 400.0)
        vinoBottone.setScale(0.5)
        self.addChild(vinoBottone)
        
        grappaBottone.position = CGPoint(x: 400.0, y: 400.0)
        grappaBottone.setScale(0.5)
        self.addChild(grappaBottone)
        
        self.addChild(audioMenu)
        
    
}


    
    override public func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let touch = touches.first
        let touchLocation = touch!.location(in: self)
        
        
        //This if is to choose if you want to play the game of wine or the grappa game, using a transition to pass to relative scene. 
        if vinoBottone.contains(touchLocation){
                let transition:SKTransition = SKTransition.fade(withDuration: 1)
                let scene:SKScene = Vino(size: self.size)
                scene.scaleMode = .aspectFit
                self.view?.presentScene(scene, transition: transition)
        }else if grappaBottone.contains(touchLocation){
            let transition:SKTransition = SKTransition.fade(withDuration: 1)
            let scene:SKScene = Grappa(size: self.size)
            scene.scaleMode = .aspectFit
            self.view?.presentScene(scene, transition: transition)
        }

    }
    
}
